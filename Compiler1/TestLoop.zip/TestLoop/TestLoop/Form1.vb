﻿
Imports System.Threading

Public Class Form1
    Public trd As Thread
    Dim a As Integer
    Public Sub AccesCom()
        If Me.InvokeRequired Then
            Me.Invoke(New MethodInvoker(AddressOf AccesCom))
        Else

            Dim stp As Integer
            Dim newval As Integer
            Dim rnd As New Random()
            stp = ProgressBar1.Step * rnd.Next(-1, 2)
            newval = ProgressBar1.Value + stp
            If newval > ProgressBar1.Maximum Then
                newval = ProgressBar1.Maximum
            ElseIf newval < ProgressBar1.Minimum Then
                newval = ProgressBar1.Minimum
            End If

            ProgressBar1.Value = newval
            Thread.Sleep(100)

            
        End If

    End Sub
    Public Sub ThreadTask()


        Do
            
            AccesCom()

            If a = 1 Then
                Exit Do

            End If
        Loop
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        trd = New Thread(AddressOf ThreadTask)
        trd.IsBackground = True
        trd.Start()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        a = 1
    End Sub

    Private Sub Button1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Button1.KeyPress
        a = 1
    End Sub
End Class
